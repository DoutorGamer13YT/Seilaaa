# iOS Banners (projeto Android em Kotlin)

Cartão de notificação em estilo iOS para as **notificações reais** do Android, via `NotificationListenerService`.

## Estado real deste projeto (leia primeiro)

- **O APK não foi gerado.** O ambiente onde o código foi escrito não tinha Android SDK e bloqueava o acesso aos repositórios do Google/Maven/Gradle. Por isso este pacote traz o projeto completo e um build automático na nuvem.
- **O código não foi compilado.** Só foi feita uma checagem de sintaxe com o compilador Kotlin; a verificação contra as APIs do Android acontece no primeiro build. Pode haver erros de compilação a corrigir.
- **Nada foi testado em aparelho**, nem no Galaxy A54 5G com One UI 8.5.
- **O AOD nativo não é suportado** (veja abaixo).
- O visual é **inspirado** nas notificações do iOS, com medidas e cores aproximadas. A fonte é a do sistema (a SF Pro é da Apple). Não consegui confirmar detalhes visuais específicos do iOS 27 para notificações.

## O que o app faz

- Lê notificações reais dos apps escolhidos (padrão: WhatsApp, WhatsApp Business, Instagram, Discord).
- Mostra um cartão no topo da tela (janela de sobreposição) com ícone ou foto, remetente, mensagem, app de origem e "agora". Entra e sai com animação; deslize para cima para dispensar; toque abre o app de origem.
- Trata conversas (última mensagem e remetente), ignora resumos de grupo, mídia, progresso e serviços, e evita repetir a mesma atualização.
- Opções: cartão escuro/claro, desfoque (experimental), remover a notificação original (ligado por padrão, evita duplicar), só o cartão com a tela apagada (experimental, ligado por padrão).
- Mostra o crédito **@vitinhjkjkk** em destaque no topo da tela principal.
- Tela com status das permissões, prévia, notificação de teste e diagnóstico.
- Sem permissão de internet: nada do conteúdo sai do aparelho nem é gravado.

## AOD (Always On Display)

Pelo que pude apurar, o AOD da Samsung é desenhado pelo sistema e mostra só ícones das notificações não lidas. Os complementos conhecidos (temas de AOD na Galaxy Store e o Clockface do Good Lock) mudam apenas o relógio. Não encontrei API pública do Android ou da One UI que permita a um app mudar a aparência das notificações no AOD, e janelas de sobreposição não aparecem com a tela apagada. Por isso **este app não altera o AOD**.

A alternativa mais próxima, ligada por padrão (opção "Só o cartão com a tela apagada"): quando a notificação chega com a tela apagada, uma Activity (`setShowWhenLocked` + `setTurnScreenOn`) acende a tela com brilho baixo, sem barras do sistema, com fundo preto puro e só o cartão. Em tela AMOLED o preto fica apagado, então visualmente sobra só a notificação, sem relógio. O cartão fica na **mesma posição do banner da tela ligada** (mesma conta em `bannerTopOffset()`, em `Ui.kt`), e tocar fora dele fecha.

Isso **não é o AOD**: a tela fica realmente ligada até o tempo limite de tela do sistema (ou 12 segundos), o que gasta mais bateria que o AOD. Um app comum não consegue apagar a tela sozinho nem desenhar com ela apagada. Depende da permissão de sobreposição e das regras de abertura em segundo plano do Android 16, e **não foi verificado**.

## Como gerar o APK

### Opção A: só pelo celular (GitHub Actions)

1. Crie um repositório no GitHub (público, para o link de download funcionar sem login).
2. Em **Add file → Upload files**, envie o arquivo `project.zip` (sem extrair).
3. Em **Add file → Create new file**, nomeie como `.github/workflows/build-apk.yml` e cole o conteúdo do arquivo `build-apk.yml` que acompanha este pacote. Confirme com **Commit**.
4. Abra a aba **Actions**; o build roda sozinho (ou use **Run workflow**). Leva alguns minutos.
5. Quando terminar, abra **Releases** no repositório e baixe `ios-banners-debug.apk`.

Se o build falhar, abra o passo "Compilar" no log, copie as mensagens de erro e envie para corrigirmos.

### Opção B: Android Studio (computador)

Abra a pasta do projeto, aguarde a sincronização e use **Build → Build APK(s)**. O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`. Pela linha de comando: `./gradlew assembleDebug` (JDK 17).

O APK gerado é de **depuração**, assinado com a chave de debug.

## Instalar e ativar no Galaxy A54

1. Abra o APK pelo app Arquivos ou Downloads. Permita "instalar apps desconhecidos" para quem pedir e, se o Play Protect avisar, toque em "Instalar mesmo assim".
2. Abra **iOS Banners**.
3. Toque em **Conceder acesso às notificações**, escolha **iOS Banners** e ative.
4. Se o Android disser "configuração restrita": toque em **Informações do app (configurações restritas)**, nos três pontos e em **Permitir configurações restritas**; depois repita o passo 3.
5. Toque em **Permitir exibir sobre outros apps** e ative.
6. Ative **Ativar banners estilo iOS**, confira os apps em **Escolher aplicativos** e use **Enviar notificação de teste** com o celular desbloqueado.
7. Para não ver dois avisos, deixe ligada a opção **Remover a notificação original** (padrão). Se o pop-up do sistema ainda piscar um instante antes de sumir, desligue o pop-up desses apps em Configurações → Notificações.
8. Se o aviso parar de chegar com o tempo, toque em **Ajustar uso de bateria** e permita "Sem restrição" e, nas configurações de bateria da Samsung, tire o app de "apps em suspensão".

## Pontos não verificados

- Compilação e execução em qualquer aparelho.
- Comportamento do desfoque em janela de sobreposição na One UI 8.5 (pode borrar a janela inteira).
- Se o Android 16 deixa o app acender a tela e abrir o cartão em segundo plano, e se o toque no cartão abre o app de origem depois de desbloquear.
- Se o brilho baixo (20%) fica legível para você; está na constante `BRIGHTNESS` de `LockCardActivity.kt`.
- Se o cartão da tela bloqueada fica exatamente na mesma altura do banner em todos os aparelhos (a conta é a mesma, mas a medida real depende da One UI).
- Se a remoção da notificação original no pop-up do sistema acontece sem piscar na One UI 8.5.
- Se o Android 15/16 permite abrir a `LockCardActivity` a partir do serviço em segundo plano com a tela apagada.
- Se o campo de detecção do AOD do sistema (`aod_mode`) existe na sua versão; o diagnóstico mostra "não detectado" se não existir.
- Foto do contato e agrupamento em cada app (dependem de como o app de origem monta a notificação).

## Mudanças desta versão (não compiladas, não testadas)

- **Sem duplicação:** "Remover a notificação original" agora vem ligada. A original só é removida depois que o cartão realmente apareceu (banner na tela ligada; `LockCardActivity` com a tela já acesa), e nunca para apps não marcados nem para notificações de serviço/ongoing/mídia/progresso. A mesma notificação (mesma chave) atualiza o cartão que já está na tela em vez de criar outro.
- **Segundo plano:** o serviço pede reconexão ao sistema em `onListenerDisconnected`; o botão de bateria pede "Sem restrição" direto (permissão `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`) e cai para a lista do sistema se não for possível. Não há serviço em primeiro plano: o `NotificationListenerService` já é mantido pelo sistema, sem notificação persistente.
- **Bateria:** o serviço decide se algo pode ser exibido antes de extrair qualquer coisa; imagens só são carregadas depois de descartar repetições; rótulos de apps e lista de apps monitorados ficam em cache; tela bloqueada fica ligada por até 12 s (antes 20 s).
- **Posição na tela bloqueada:** banner e cartão da tela bloqueada usam a mesma conta de topo; a janela da `LockCardActivity` passa a ignorar o recorte da câmera (`SHORT_EDGES`) e, no Android 10, fixa o layout a partir do topo físico; a posição aleatória foi removida.
- **Crédito:** @vitinhjkjkk em destaque na tela principal.

## Estrutura

- `NotificationService.kt`: recebe e filtra notificações, extrai conteúdo, decide onde exibir.
- `BannerOverlay.kt` e `NotificationCardView.kt`: janela de sobreposição, animações, gesto e visual do cartão.
- `LockCardActivity.kt`: alternativa experimental na tela bloqueada.
- `MainActivity.kt` e `AppPickerActivity.kt`: configuração, prévia, teste, diagnóstico e seleção de apps.
- `Prefs.kt`, `CardData.kt`, `Ui.kt`: configurações, modelo de dados e utilitários.
