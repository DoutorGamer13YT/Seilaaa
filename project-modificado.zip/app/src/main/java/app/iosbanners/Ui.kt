package app.iosbanners

import android.content.Context
import android.util.TypedValue

fun Context.dp(v: Float): Int =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

fun Context.dp(v: Int): Int = dp(v.toFloat())

/** Crédito do desenvolvedor exibido na tela principal. */
const val CREDIT_HANDLE = "@vitinhjkjkk"

/** Altura da barra de status (px); usa 28dp se o sistema não informar. */
fun Context.statusBarHeightPx(): Int {
    val id = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
}

/**
 * Distância do topo físico da tela até o cartão. É a MESMA conta para o banner (tela ligada)
 * e para o cartão da tela bloqueada, para que os dois fiquem alinhados.
 */
fun Context.bannerTopOffset(): Int = statusBarHeightPx() + dp(4)
