package app.iosbanners

import android.app.KeyguardManager
import android.app.Notification
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Recebe as notificações reais do sistema (API oficial NotificationListenerService)
 * e as repassa ao banner. Não armazena nem transmite o conteúdo.
 *
 * Funcionamento em segundo plano: o sistema mantém este serviço vinculado enquanto o acesso às
 * notificações estiver concedido; ele só consome CPU quando chega uma notificação (sem loops,
 * timers nem serviço em primeiro plano). Se o sistema (ou a One UI) o desconectar, pedimos a
 * reconexão em [onListenerDisconnected].
 */
class NotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var connected: Boolean = false

        @Volatile
        private var instance: NotificationService? = null

        /** Marca a notificação de teste enviada pelo próprio app (botão "Enviar teste"). */
        const val EXTRA_IS_TEST = "app.iosbanners.IS_TEST"
        private const val TAG = "IosBanners"

        /**
         * Remove a notificação original (se a opção estiver ligada). Chamado só depois que o
         * cartão estilo iOS apareceu de fato, para nunca ficar sem nenhuma das duas.
         */
        fun removeOriginalIfEnabled(key: String) {
            instance?.removeOriginal(key)
        }
    }

    private enum class Route { NONE, OVERLAY, LOCK }

    private lateinit var overlay: BannerOverlay
    private val lastHash = HashMap<String, Int>()
    private val labelCache = HashMap<String, String>()

    /** Chaves que nós mesmos removemos (para não repetir o cartão se o app republicar igual). */
    private val removedByUs = HashSet<String>()

    override fun onCreate() {
        super.onCreate()
        overlay = BannerOverlay(this)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        overlay.release()
        super.onDestroy()
    }

    override fun onListenerConnected() {
        connected = true
        instance = this
    }

    override fun onListenerDisconnected() {
        connected = false
        if (instance === this) instance = null
        // Pede ao sistema para vincular o serviço de novo (permitido pela API; sem loop próprio).
        try {
            NotificationListenerService.requestRebind(ComponentName(this, NotificationService::class.java))
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível pedir a reconexão do serviço", e)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        val key = sbn?.key ?: return
        // Se fomos nós que removemos, mantém o hash: evita repetir o cartão se o app republicar o mesmo conteúdo.
        if (!removedByUs.remove(key)) lastHash.remove(key)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (t: Throwable) {
            Log.e(TAG, "Falha ao processar notificação", t)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        val n = sbn.notification ?: return
        val pkg = sbn.packageName
        val ownPackage = pkg == packageName

        // Do próprio app, só passa a notificação de teste.
        val extras = n.extras
        if (ownPackage && extras?.getBoolean(EXTRA_IS_TEST, false) != true) return
        if (!ownPackage && pkg !in Prefs.monitoredApps(this)) return

        // Ignora resumos de grupo, serviços em primeiro plano, mídia e progresso.
        // (Essas notificações nunca são removidas por este app.)
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE)) != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS -> return
        }
        if (extras == null) return

        // Decide primeiro se algo poderá ser exibido; se não, não gasta CPU extraindo nada.
        val route = pickRoute()
        if (route == Route.NONE) return

        val appName = appLabel(pkg)

        var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (body.isBlank()) {
            body = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                ?.lastOrNull()?.toString().orEmpty()
        }
        var avatarIcon: Icon? = null
        var messageCount = 0

        // Conversas (MessagingStyle): pega a última mensagem, o remetente e a foto.
        @Suppress("DEPRECATION")
        val rawMessages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (rawMessages != null && rawMessages.isNotEmpty()) {
            val list = Notification.MessagingStyle.Message.getMessagesFromBundleArray(rawMessages)
            if (list.isNotEmpty()) {
                val last = list.last()
                val lastText = last.text?.toString().orEmpty()
                val person = last.senderPerson
                val senderName = person?.name?.toString().orEmpty()
                val conversation = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                messageCount = list.size
                if (lastText.isNotEmpty()) {
                    if (!conversation.isNullOrEmpty()) {
                        title = conversation
                        body = if (senderName.isNotEmpty()) "$senderName: $lastText" else lastText
                    } else {
                        if (senderName.isNotEmpty()) title = senderName
                        body = lastText
                    }
                }
                avatarIcon = person?.icon
            }
        }

        if (title.isBlank()) title = appName
        if (title.isBlank() && body.isBlank()) return

        // Evita repetir a mesma atualização da mesma notificação (antes de carregar imagens).
        val hash = (title + "\u0000" + body + "\u0000" + messageCount + "\u0000" + n.`when`).hashCode()
        if (lastHash[sbn.key] == hash) return
        if (lastHash.size > 300) lastHash.clear()
        lastHash[sbn.key] = hash

        // Imagens só são carregadas quando o cartão realmente será montado.
        val appIcon: Drawable? = try {
            packageManager.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }
        val avatar: Drawable? = loadIcon(avatarIcon) ?: loadIcon(n.getLargeIcon())

        val data = CardData(
            key = sbn.key,
            packageName = pkg,
            appName = appName,
            title = title,
            body = body,
            appIcon = appIcon,
            avatar = avatar,
            contentIntent = n.contentIntent,
            postTime = sbn.postTime
        )
        deliver(data, route)
    }

    private fun loadIcon(icon: Icon?): Drawable? = try {
        icon?.loadDrawable(this)
    } catch (e: Exception) {
        null
    }

    private fun appLabel(pkg: String): String {
        labelCache[pkg]?.let { return it }
        val label = try {
            val pm = packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        if (labelCache.size > 100) labelCache.clear()
        labelCache[pkg] = label
        return label
    }

    /** Escolhe onde exibir conforme o estado da tela; NONE se nada puder ser exibido agora. */
    private fun pickRoute(): Route {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val screenOn = pm?.isInteractive != false
        val locked = km?.isKeyguardLocked == true
        val canDraw = Settings.canDrawOverlays(this)
        return when {
            screenOn && !locked -> if (canDraw) Route.OVERLAY else Route.NONE
            // Experimental: com a tela apagada, acende fraco só o cartão sobre fundo preto
            // (não é o AOD). A original só é removida depois que o cartão aparecer.
            !screenOn && Prefs.lockCard(this) && canDraw -> Route.LOCK
            else -> Route.NONE
        }
    }

    private fun deliver(data: CardData, route: Route) {
        when (route) {
            Route.OVERLAY -> {
                // Só remove a original se o nosso cartão realmente apareceu.
                if (overlay.show(data)) removeOriginal(data.key)
            }
            Route.LOCK -> {
                try {
                    CardStore.pending = data
                    val i = Intent(this, LockCardActivity::class.java)
                    i.addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    startActivity(i)
                } catch (e: Exception) {
                    Log.w(TAG, "Não foi possível abrir o cartão na tela bloqueada", e)
                }
            }
            Route.NONE -> Unit
        }
    }

    private fun removeOriginal(key: String) {
        if (!Prefs.hideOriginal(this)) return
        try {
            if (removedByUs.size > 100) removedByUs.clear()
            removedByUs.add(key)
            cancelNotification(key)
        } catch (e: Exception) {
            removedByUs.remove(key)
            Log.w(TAG, "Não foi possível remover a original", e)
        }
    }
}
